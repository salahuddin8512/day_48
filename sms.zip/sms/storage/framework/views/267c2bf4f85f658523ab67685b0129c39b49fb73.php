<?php $__env->startSection('body'); ?>
    <section class="py-5">
        <div class="container">
            <div class="row">
                <div class="col-md-3">
                    <div class="card">
                        <div class="list-group list-group-flush">
                            <a href="" class="list-group-item">My All Course</a>
                            <a href="<?php echo e(route('student-profile')); ?>" class="list-group-item">My Profile</a>
                            <a href="<?php echo e(route('change-password')); ?>" class="list-group-item">Change Password</a>
                            <a href="" class="list-group-item">My Payment</a>
                        </div>
                    </div>
                </div>
                <div class="col-md-9">
                    <div class="card">
                        <div class="card-header">My Profile Information</div>
                        <div class="card-body">
                            <p class="text-center text-success"><?php echo e(Session::get('message')); ?></p>
                            <form action="<?php echo e(route('update-student-profile', ['id' =>$student->id])); ?>" method="POST" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <div class="row mb-3">
                                    <label class="col-md-3"></label>
                                    <div class="col-md-9">
                                        <img src="<?php echo e(asset($student->image)); ?>" alt="<?php echo e($student->name); ?>" height="200" width="200"/><br/>
                                        <input type="file" class="form-control" name="image" accept="image/*"/>
                                    </div>
                                </div>
                                <div class="row mb-3">
                                    <label class="col-md-3">Full Name</label>
                                    <div class="col-md-9">
                                        <input type="text" value="<?php echo e($student->name); ?>" class="form-control" name="name">
                                    </div>
                                </div>
                               <div class="row mb-3">
                                   <label class="col-md-3">Email</label>
                                   <div class="col-md-9">
                                       <input type="email" value="<?php echo e($student->email); ?>" class="form-control" name="email">
                                   </div>
                               </div>
                                <div class="row mb-3">
                                    <label class="col-md-3">mobile</label>
                                    <div class="col-md-9">
                                        <input type="number" value="<?php echo e($student->mobile); ?>" class="form-control" name="mobile">
                                    </div>
                                </div>
                                <div class="row mb-3">
                                    <label class="col-md-3"></label>
                                    <div class="col-md-9">
                                        <input type="submit" value="Update Information" class="btn btn-success" name="btn">
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.front.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sms\resources\views/student/profile/profile.blade.php ENDPATH**/ ?>