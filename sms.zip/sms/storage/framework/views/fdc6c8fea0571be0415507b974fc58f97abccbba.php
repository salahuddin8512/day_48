<?php $__env->startSection('body'); ?>
    <div class="row">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-body">
                    <h4 class="card-title">Manage Course</h4>
                    <div class="table-responsive">
                        <table class="table table-bordered table-hover mb-0">
                            <p class="text-center text-success"><?php echo e(Session::get('message')); ?></p>
                            <thead>
                            <tr>
                                <th>#</th>
                                <th>Course Title</th>
                                <th>Teacher Name</th>
                                <th>Student Name</th>
                                <th>Student mobile</th>
                                <th>Enroll Status</th>
                                <th>Payment Status</th>
                                <th>Action</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $enrolls; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $enroll): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th scope="row"><?php echo e($loop->iteration); ?></th>
                                    <td><?php echo e($enroll['course_title']); ?></td>
                                    <td><?php echo e($enroll['teacher_name']); ?></td>
                                    <td><?php echo e($enroll['student_name']); ?></td>
                                    <td><?php echo e($enroll['student_mobile']); ?></td>
                                    <td><?php echo e($enroll['enroll-status']); ?></td>
                                    <td><?php echo e($enroll['payment-status']); ?></td>

                                    <td>
                                        <a href="<?php echo e(route('update-enroll-status', ['id' =>$enroll['enroll_id']])); ?>" class="btn <?php echo e($enroll['enroll-status'] == 'pending' ? 'btn-warning' : 'btn-success disabled'); ?> btn-sm">
                                            <i class="fa fa-upload"></i></a>

                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sms\resources\views/admin/student/manage-course.blade.php ENDPATH**/ ?>