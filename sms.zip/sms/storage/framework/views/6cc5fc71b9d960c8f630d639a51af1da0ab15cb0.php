<?php $__env->startSection('body'); ?>
    <section class="notice-section py-5">
        <div class="container">
            <h4 class="text-center"><?php echo e(Session::get('message')); ?></h4>
            <div class="carousel slide" data-bs-ride="carousel" data-bs-interval="2000">
                <div class="carousel-inner">
                    <div class="carousel-item active">
                        <div class="card card-body">
                          <h3 class="card-title">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Autem doloremque eveniet impedit molestias nostrum numquam omnis perferendis quibusdam repellat suscipit.</h3>
                           <hr/>
                            <p class="card-text">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Fugit inventore laboriosam magni voluptate. Autem delectus, deserunt distinctio doloribus in minus omnis porro possimus quaerat saepe sequi sint tempore temporibus totam.</p>
                           <p class="card-text">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Fugit inventore laboriosam magni voluptate. Autem delectus, deserunt distinctio doloribus in minus omnis porro possimus quaerat saepe sequi sint tempore temporibus totam.</p>
                        </div>
                    </div>
                    <div class="carousel-item">
                        <div class="card card-body">
                            <h3 class="card-title">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Autem doloremque eveniet impedit molestias nostrum numquam omnis perferendis quibusdam repellat suscipit.</h3>
                            <hr/>
                            <p class="card-text">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Fugit inventore laboriosam magni voluptate. Autem delectus, deserunt distinctio doloribus in minus omnis porro possimus quaerat saepe sequi sint tempore temporibus totam.</p>
                            <p class="card-text">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Fugit inventore laboriosam magni voluptate. Autem delectus, deserunt distinctio doloribus in minus omnis porro possimus quaerat saepe sequi sint tempore temporibus totam.</p>
                        </div>
                    </div>
                    <div class="carousel-item">
                        <div class="card card-body">
                            <h3 class="card-title">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Autem doloremque eveniet impedit molestias nostrum numquam omnis perferendis quibusdam repellat suscipit.</h3>
                            <hr/>
                            <p class="card-text">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Fugit inventore laboriosam magni voluptate. Autem delectus, deserunt distinctio doloribus in minus omnis porro possimus quaerat saepe sequi sint tempore temporibus totam.</p>
                            <p class="card-text">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Fugit inventore laboriosam magni voluptate. Autem delectus, deserunt distinctio doloribus in minus omnis porro possimus quaerat saepe sequi sint tempore temporibus totam.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
  <section class="py-5">
      <div class="container">
          <div class="row">
              <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <div class="col-md-6">
                  <div class="card mb-3">
                      <div class="row g-0">
                          <div class="col-md-5">
                              <img src="<?php echo e(asset($subject->image)); ?>" class="img-fluid h-100" alt="...">
                          </div>
                          <div class="col-md-7">
                              <div class="card-body">
                                  <figure>
                                      <blockquote class="blockquote">
                                          <p><?php echo e($subject->title); ?></p>
                                      </blockquote>
                                      <figcaption class="blockquote-footer">
                                          <?php echo e($subject->teacher->name); ?>

                                      </figcaption>
                                  </figure>
                                  <div><?php echo $subject->short_description; ?>}</div>
                                  <p class="card-text"><small class="text-muted">Last date of admission</small></p>
                                  <a href="<?php echo e(route('course-detail', ['id' =>$subject->id])); ?>" class="btn btn-success">Read More</a>
                                  <a href="" class="btn btn-success float-end">Apply Now</a>
                              </div>
                          </div>
                      </div>
                  </div>
              </div>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>
      </div>
  </section>
  <section class="py-5 bg-secondary">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="card card-body">
                        <div class="row">
                            <div class="col-9">
                                <input type="text" class="form-control" placeholder="Enter your email here"/>
                            </div>
                            <div class="col-3">
                                <input type="submit" class="btn btn-success w-100" value="Subscribe Now"/>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
  </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.front.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sms\resources\views/website/home/home.blade.php ENDPATH**/ ?>