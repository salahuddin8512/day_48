<?php $__env->startSection('body'); ?>
    <section class="py-5">
        <div class="container">
            <div class="row">
                <div class="col-md-3">
                    <div class="card">
                        <div class="list-group list-group-flush">
                            <a href="" class="list-group-item">My All Course</a>
                            <a href="<?php echo e(route('student-profile')); ?>" class="list-group-item">My Profile</a>
                            <a href="<?php echo e(route('change-password')); ?>" class="list-group-item">Change Password</a>
                            <a href="" class="list-group-item">My Payment</a>
                        </div>
                    </div>
                </div>
                <div class="col-md-9">
                    <div class="card">
                        <div class="card-header">Change Password</div>
                        <div class="card-body">
                            <p class="text-center text-success"><?php echo e(Session::get('message')); ?></p>
                            <form action="<?php echo e(route('update-student-password', ['id' =>$id])); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <div class="row mb-3">
                                    <label class="col-md-3">Previous Password</label>
                                    <div class="col-md-9">
                                        <input type="password"  class="form-control" name="prev_password">
                                    </div>
                                </div>
                                <div class="row mb-3">
                                    <label class="col-md-3">New Password</label>
                                    <div class="col-md-9">
                                        <input type="password" class="form-control" name="password">
                                    </div>
                                </div>

                                <div class="row mb-3">
                                    <label class="col-md-3"></label>
                                    <div class="col-md-9">
                                        <input type="submit" value="Update Password Information" class="btn btn-success" name="btn">
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.front.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sms\resources\views/student/profile/change-password.blade.php ENDPATH**/ ?>